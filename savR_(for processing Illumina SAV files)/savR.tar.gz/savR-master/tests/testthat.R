library(testthat)
library(savR)

test_check("savR")

savR
================================

*savR* is an R package to parse Illumina Sequence Analysis Viewer (InterOp)
files for downstream analysis.

Current release version 1.8.1.

Example
--------

```
library(savR)
example(savR)
```
